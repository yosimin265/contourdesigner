/** Procedural water only. getH(x,z) is the carved terrain height. */
export function addWater(T, scene, getH, { low = false, streamPoints = [[29,38],[23,45],[18,55],[21,66],[12,80],[8,96],[0,112]] } = {}) {
  const group = new T.Group(); group.name = 'pond-and-stream'; scene.add(group);
  let seed=71381; const rnd=()=>((seed=(1664525*seed+1013904223)>>>0)/4294967296);
  // WebGPU compatible: physical material plus analytic vertex colours.
  const waterMaterial = () => new T.MeshPhysicalMaterial({
    vertexColors:true, color:0xffffff, roughness:.28, metalness:.08,
    clearcoat:.75, clearcoatRoughness:.23, side:T.DoubleSide
  });
  function tintWater(geometry,stream=false){
    const a=geometry.getAttribute('position'),u=geometry.getAttribute('uv'),colors=[];
    const shallow=new T.Color(0x79b9a0),deep=new T.Color(0x287b86),sky=new T.Color(0xb5d4ce);
    for(let i=0;i<a.count;i++){
      const x=a.getX(i),z=a.getZ(i),r=Math.hypot((x-39)/27,(z-22)/18);
      const depth=5*Math.max(0,1-r*r),f=stream?Math.sin(u.getX(i)*Math.PI)*.7:Math.min(1,depth/4.8);
      const c=shallow.clone().lerp(deep,f);
      const clouds=(Math.sin(x*.105+z*.16)+Math.sin(x*.22-z*.09)+2)/4;
      c.lerp(sky,Math.pow(clouds,3)*.19);colors.push(c.r,c.g,c.b);
    }
    geometry.setAttribute('color',new T.Float32BufferAttribute(colors,3));
  }
  // Exact ellipse: single planar surface, colour derives from a 5m analytic basin.
  const n=low?80:144, rings=low?12:24, pos=[39,.025,22],uv=[.5,.5],idx=[];
  for(let j=1;j<=rings;j++)for(let i=0;i<=n;i++){
    const a=i/n*Math.PI*2,r=j/rings;pos.push(39+27*r*Math.cos(a),.025,22+18*r*Math.sin(a));uv.push(.5+.5*r*Math.cos(a),.5+.5*r*Math.sin(a));
    if(i<n){const k=1+(j-1)*(n+1)+i;if(j===1)idx.push(0,k,k+1);else{const prev=k-(n+1);idx.push(prev,k,prev+1,prev+1,k,k+1);}}
  }
  const pg=new T.BufferGeometry();pg.setAttribute('position',new T.Float32BufferAttribute(pos,3));pg.setAttribute('uv',new T.Float32BufferAttribute(uv,2));pg.setIndex(idx);pg.computeVertexNormals();tintWater(pg);
  const pond=new T.Mesh(pg,waterMaterial());pond.name='elliptical-pond';group.add(pond);
  const points=streamPoints.length>1?streamPoints:[[29,38],[0,112]];
  const curve=new T.CatmullRomCurve3(points.map(p=>new T.Vector3(p[0],0,p[1])),false,'centripetal');
  const count=low?100:220, vertices=[],suv=[],indices=[], samples=[];
  for(let i=0;i<=count;i++){
    const t=i/count,p=curve.getPoint(t),d=curve.getTangent(t),normal=new T.Vector3(-d.z,0,d.x).normalize();
    const width=3.35+.3*Math.sin(t*21)+.18*Math.sin(t*63);
    // Blend gently out of the pond so no step or crack appears at the outlet.
    const blend=Math.min(1,t*22), y=(getH(p.x,p.z)+.35)*blend+.025*(1-blend);
    samples.push({p,normal,width,y,t});
    for(const side of [-1,-.5,0,.5,1]){vertices.push(p.x+normal.x*width*.5*side,y,p.z+normal.z*width*.5*side);suv.push((side+1)/2,t);}
    if(i<count)for(let j=0;j<4;j++){const k=i*5+j;indices.push(k,k+5,k+1,k+1,k+5,k+6);}
  }
  const sg=new T.BufferGeometry();sg.setAttribute('position',new T.Float32BufferAttribute(vertices,3));sg.setAttribute('uv',new T.Float32BufferAttribute(suv,2));sg.setIndex(indices);sg.computeVertexNormals();tintWater(sg,true);
  const stream=new T.Mesh(sg,waterMaterial(true));stream.name='winding-stream';group.add(stream);
  // Smooth, low rounded stone clusters, not a uniform necklace around the lake.
  const rockGeo=new T.IcosahedronGeometry(1,low?1:2);
  const rockMats=[0x8d9480,0xa3a48e,0x727f72,0xb1af98].map(color=>new T.MeshStandardMaterial({color,roughness:1}));
  const rockMatrices=rockMats.map(()=>[]),rockDummy=new T.Object3D();
  function stone(x,z,s,waterY=null){
    const materialIndex=Math.floor(rnd()*rockMats.length),h=getH(x,z);
    rockDummy.position.set(x,waterY===null?h+.04:Math.max(h,waterY-.28),z);
    rockDummy.scale.set(s*(.9+rnd()*.6),s*(.35+rnd()*.3),s*(.7+rnd()*.55));
    rockDummy.rotation.set(rnd()*.2,rnd()*6.28,rnd()*.2);rockDummy.updateMatrix();
    rockMatrices[materialIndex].push(rockDummy.matrix.clone());
  }
  for(let i=0;i<(low?85:150);i++){const a=rnd()*Math.PI*2;if(a>1.72&&a<2.12)continue;if(rnd()<.22)continue;const radius=1.005+rnd()*.032;stone(39+27*radius*Math.cos(a),22+18*radius*Math.sin(a),.35+rnd()*.7);}
  for(let i=4;i<samples.length;i+=(low?4:3)){const s=samples[i];for(const sign of [-1,1]){if(rnd()<.2)continue;const offset=s.width*.5+.15+rnd()*.6;stone(s.p.x+s.normal.x*offset*sign,s.p.z+s.normal.z*offset*sign,.32+rnd()*.6,s.y);}}
  rockMatrices.forEach((matrices,i)=>{
    const rocks=new T.InstancedMesh(rockGeo,rockMats[i],matrices.length);
    rocks.name='water-bank-stones-'+i;
    matrices.forEach((matrix,j)=>rocks.setMatrixAt(j,matrix));
    rocks.instanceMatrix.needsUpdate=true;rocks.castShadow=true;rocks.receiveShadow=true;
    rocks.computeBoundingSphere();group.add(rocks);
  });
  // Reed blades and pale seed-heads catch the light along quiet shoreline pockets.
  const reedMat=new T.MeshStandardMaterial({color:0x8e9c54,roughness:1,side:T.DoubleSide});
  const reedPos=[],reedIndices=[], heads=[];
  function reeds(x,z){const y=getH(x,z)+.05;for(let j=0;j<5;j++){const xx=x+(rnd()-.5)*.7,zz=z+(rnd()-.5)*.7,h=.65+rnd()*1.5,lean=.12+rnd()*.35,ang=rnd()*6.28,dx=Math.cos(ang),dz=Math.sin(ang),k=reedPos.length/3;
    reedPos.push(xx-dz*.035,y,zz+dx*.035,xx+dz*.035,y,zz-dx*.035,xx+lean*dx,y+h,zz+lean*dz);reedIndices.push(k,k+1,k+2);if(j<2)heads.push([xx+lean*dx,y+h,zz+lean*dz]);}}
  for(let i=0;i<(low?20:40);i++){const a=rnd()*Math.PI*2;if(a>1.7&&a<2.2)continue;reeds(39+27.7*Math.cos(a),22+18.6*Math.sin(a));}
  for(let i=15;i<samples.length;i+=17){const s=samples[i],sign=rnd()<.5?-1:1;reeds(s.p.x+s.normal.x*(s.width*.5+.9)*sign,s.p.z+s.normal.z*(s.width*.5+.9)*sign);}
  const rg=new T.BufferGeometry();rg.setAttribute('position',new T.Float32BufferAttribute(reedPos,3));rg.setIndex(reedIndices);rg.computeVertexNormals();group.add(new T.Mesh(rg,reedMat));
  const headGeo=new T.SphereGeometry(1,5,4),headMat=new T.MeshStandardMaterial({color:0xd3c896,roughness:1});
  const headMesh=new T.InstancedMesh(headGeo,headMat,heads.length),dummy=new T.Object3D();heads.forEach((p,i)=>{dummy.position.set(...p);dummy.scale.set(.07,.23,.07);dummy.updateMatrix();headMesh.setMatrixAt(i,dummy.matrix);});group.add(headMesh);
  // Two batched line draws. RGBA vertex colours preserve each stroke's
  // independent opacity phase; only lake positions and both alpha buffers animate.
  function makeBatch(color,stream){return {color:new T.Color(color),stream,positions:[],colors:[],strokes:[]};}
  const lakeLines=makeBatch(0xc4e0d7,false),streamLines=makeBatch(0xd7e5d6,true);
  function addStroke(batch,pts){
    const start=batch.positions.length/3,phase=rnd()*6.28;
    for(let i=1;i<pts.length;i++)for(const p of [pts[i-1],pts[i]]){
      batch.positions.push(p.x,p.y,p.z);batch.colors.push(batch.color.r,batch.color.g,batch.color.b,batch.stream?.38:.15);
    }
    batch.strokes.push({start,count:batch.positions.length/3-start,phase});
  }
  for(let j=0;j<(low?14:28);j++){
    const z=9+rnd()*25,x=21+rnd()*34;
    if(Math.hypot((x-39)/27,(z-22)/18)>.87)continue;
    const pts=[],length=1+rnd()*3.8;
    for(let k=0;k<9;k++)pts.push(new T.Vector3(x+(k/8-.5)*length,.065,z+Math.sin(k/8*Math.PI)*.08));
    addStroke(lakeLines,pts);
  }
  for(let i=8;i<samples.length;i+=low?13:9){
    const s=samples[i],pts=[];
    for(let k=0;k<7;k++){const f=(k/6-.5)*s.width*.55;pts.push(new T.Vector3(s.p.x+s.normal.x*f,s.y+.07,s.p.z+s.normal.z*f+Math.sin(k)*.08));}
    addStroke(streamLines,pts);
  }
  const batches=[lakeLines,streamLines];
  for(const batch of batches){
    const geometry=new T.BufferGeometry();
    batch.positionAttribute=new T.Float32BufferAttribute(batch.positions,3);
    batch.colorAttribute=new T.Float32BufferAttribute(batch.colors,4);
    if(!batch.stream)batch.positionAttribute.setUsage(T.DynamicDrawUsage);
    batch.colorAttribute.setUsage(T.DynamicDrawUsage);
    geometry.setAttribute('position',batch.positionAttribute);geometry.setAttribute('color',batch.colorAttribute);
    geometry.computeBoundingSphere();geometry.boundingSphere.radius+=.13;
    const material=new T.LineBasicMaterial({color:0xffffff,vertexColors:true,transparent:true,opacity:1,depthWrite:false});
    const lines=new T.LineSegments(geometry,material);lines.name=batch.stream?'stream-foam-batch':'pond-shimmer-batch';group.add(lines);
  }
  return elapsed => { const t=Number.isFinite(elapsed)?elapsed:0;
    for(const batch of batches){
      const positions=batch.positionAttribute.array,colors=batch.colorAttribute.array;
      for(const stroke of batch.strokes){
        const opacity=(batch.stream?.38:.15)+Math.sin(t*(batch.stream?1.7:.65)+stroke.phase)*(batch.stream?.14:.08);
        const dz=batch.stream?0:Math.sin(t*.38+stroke.phase)*.12;
        for(let i=stroke.start;i<stroke.start+stroke.count;i++){
          colors[i*4+3]=opacity;if(!batch.stream)positions[i*3+2]=batch.positions[i*3+2]+dz;
        }
      }
      batch.colorAttribute.needsUpdate=true;if(!batch.stream)batch.positionAttribute.needsUpdate=true;
    }
  };
}
