export const streamPoints=[[29,38],[25,44],[20,49],[17,55],[18,60],[15,65],[9,72],[11,79],[7,86],[2,94],[3,102],[0,112],[1,124],[0,138]];
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const smooth=(a,b,v)=>{const x=clamp((v-a)/(b-a),0,1);return x*x*(3-2*x)};
function hash(x,z){let k=Math.imul(x,374761393)+Math.imul(z,668265263);k=Math.imul(k^(k>>>13),1274126177);return ((k^(k>>>16))>>>0)/4294967295}
function noise(x,z){const i=Math.floor(x),j=Math.floor(z),f=smooth(0,1,x-i),g=smooth(0,1,z-j);return (hash(i,j)*(1-f)+hash(i+1,j)*f)*(1-g)+(hash(i,j+1)*(1-f)+hash(i+1,j+1)*f)*g}
export function nearLine(x,z,line){let d=1e9,zz=0;for(let i=1;i<line.length;i++){const a=line[i-1],b=line[i],dx=b[0]-a[0],dz=b[1]-a[1],l=dx*dx+dz*dz;const t=clamp(((x-a[0])*dx+(z-a[1])*dz)/l,0,1),xx=a[0]+t*dx, z0=a[1]+t*dz;const u=(x-xx)**2+(z-z0)**2;if(u<d){d=u;zz=z0}}return [Math.sqrt(d),zz]}
const route1=[[85,-31],[80,-41],[74,-42],[71,-48],[65,-56],[68,-63],[82,-65],[87,-55],[92,-48]];
const route2=[[87,-29],[75,-30],[61,-31],[47,-28],[30,-25],[14,-19],[3,-11],[-5,4],[-16,19],[-24,28],[-42,40],[-48,53],[-51,62],[-58,68]];
export const routes=[route1,route2];
export const pondR=(x,z)=>Math.hypot((x-39)/27,(z-22)/18);
const g=(x,z,cx,cz,rx,rz)=>Math.exp(-(((x-cx)/rx)**2+((z-cz)/rz)**2));
export function getH(x,z){
 const r=pondR(x,z);
 const hillRadius=Math.hypot((x+47)/43,(z+26)/37);
 const hill=34.1553526421*Math.exp(-Math.pow(hillRadius,2.32))* (1-.06*Math.sin(hillRadius*2)*Math.sin(x*.18+z*.11));
 const fore=-Math.max(0,z-40)*.045;
 const rough=(noise(x*.037+3,z*.036)-.5)*3.3+(noise(x*.12,z*.13)-.5)*.8+(noise(x*.39,z*.41)-.5)*.16;
 let h=4.3+fore+hill+26*g(x,z,-145,-130,61,65)+34*g(x,z,98,-154,105,45)+11*g(x,z,-101,-62,24,34)+10*g(x,z,96,44,36,49)+8*g(x,z,-83,88,45,38)+10*g(x,z,43,-51,65,27)+4*g(x,z,91,-69,27,21)+rough;
 // Rim rises to blend with the surrounding hills, with a shallower lip at the outlet.
 if(r<1)h=-5+5*r*r;
 else if(r<1.64)h*=smooth(1,1.60,r);
 const [d,cz]=nearLine(x,z,streamPoints);
 if(d<13&&z>36&&r>.97){let bed=-.44-Math.max(0,cz-38)*.038-(Math.max(0,cz-65)*.013);
 const kind=smooth(1.35,7.8,d)*.9+smooth(6.9,12,d)*.1;
 h=bed*(1-kind)+h*kind;
 }
 return h;
}
function texture(T,low){const canvas=document.createElement('canvas');canvas.width=canvas.height=128;const ctx=canvas.getContext('2d');ctx.fillStyle='#dad7be';ctx.fillRect(0,0,128,128);
 for(let i=0;i<5400;i++){const x=hash(i,45)*128,y=hash(i,49)*128,l=1+hash(i,54)*3,a=.025+hash(i,62)*.16;ctx.fillStyle=hash(i,38)>.48?'rgba(255,254,213,'+a+')':'rgba(58,65,28,'+a+')';ctx.fillRect(x,y,1,l);}
 const t=new T.CanvasTexture(canvas);t.colorSpace=T.SRGBColorSpace;t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(123,123);t.anisotropy=low?2:8;return t;}
export function addTerrain(T,scene,low){
 const geo=new T.PlaneGeometry(410,390,low?208:402,low?202:382);geo.rotateX(-Math.PI/2);
 const p=geo.attributes.position,col=new Float32Array(p.count*3);
 const grassA=new T.Color('#7e994e'),grassB=new T.Color('#ced180'),forest=new T.Color('#527454'),brown=new T.Color('#a89e73'),path=new T.Color('#d4b783'),wet=new T.Color('#6d8260'),shore=new T.Color('#889759'),deep=new T.Color('#387567'),rock=new T.Color('#9a9b79');
 const C=new T.Color();
 for(let i=0;i<p.count;i++){
  const x=p.getX(i), z=p.getZ(i)-38,h=getH(x,z);
  p.setXYZ(i,x,h,z);
  const slope=Math.hypot(getH(x+.45,z)-getH(x-.45,z),getH(x,z+.45)-getH(x,z-.45))/.9;
  const n1=noise(x*.067,z*.072), n2=noise(x*.24+17,z*.23+9), n3=noise(x*.83,z*.86);
  C.copy(grassA).lerp(grassB,clamp(.02+n1*.80+n2*.25,0,1));
  C.lerp(forest,.28*smooth(.37,.74,noise(x*.028-12,z*.027)+.13*(z<-58))+.14*smooth(.26,.84,slope));
  C.lerp(forest,.23*smooth(.51,.82,noise(x*.111+n1,z*.142-n2)));
  C.lerp(grassB,.20*smooth(.48,.79,noise(x*.15-8,z*.20+33)));
  C.lerp(rock,.44*smooth(.51,.84,slope)*smooth(.48,.72,n1*.55+n2*.45));
  C.lerp(brown,.29*smooth(.58,.88,n2*.4+n3*.6));
  const [rd]=nearLine(x,z,route1),[rd2]=nearLine(x,z,route2);
  C.lerp(path,.85*(1-smooth(.65,2.6,Math.min(rd,rd2))));
  const r=pondR(x,z);
  C.lerp(shore,(1-smooth(.06,.25,Math.abs(r-1)))*.73);
  if(r<1)C.lerp(deep,.85*(1-r));
  if(z>34){const [d]=nearLine(x,z,streamPoints);C.lerp(wet,.7*(1-smooth(1.1,4.2,d)));}
  C.multiplyScalar(.82+n3*.24+n2*.1);
  col.set([C.r,C.g,C.b],i*3);
 }
 geo.computeVertexNormals();geo.setAttribute('color',new T.BufferAttribute(col,3));
 const mesh=new T.Mesh(geo,new T.MeshStandardMaterial({vertexColors:true,map:texture(T,low),roughness:1}));mesh.receiveShadow=!low;scene.add(mesh);
}
export function addContours(T,scene){
 const layer=new T.Group(), hill=[6,12,18,24,30,36], lake=[0,-2,-4];layer.visible=false;scene.add(layer);
 function make(x,z,h,ry,material,isPond=false){
 const arr=[];for(let i=0;i<=192;i++){let a=i/192*Math.PI*2;
  let radius=1;
  if(isPond){radius=Math.sqrt((h+5)/5)*.995;}
  else{let lo=0,hi=1.85;for(let j=0;j<14;j++){let m=(lo+hi)/2;const test=getH(x+Math.cos(a)*43*m,z+Math.sin(a)*ry*m);if(test>h)lo=m;else hi=m}radius=(lo+hi)/2;}
  const xx=x+Math.cos(a)*(isPond?27:43)*radius,zz=z+Math.sin(a)*ry*radius;
  arr.push(new T.Vector3(xx,isPond?.34+(-h*.055):getH(xx,zz)+.15,zz));
 }
 layer.add(new T.Line(new T.BufferGeometry().setFromPoints(arr),material));}
 let a=new T.LineBasicMaterial({color:0xfadc89}),b=new T.LineBasicMaterial({color:0xa9f2ff});
 for(const y of hill)make(-47,-26,y,37,a);
 for(const y of lake)make(39,22,y,18,b,true);
 return layer;
}
