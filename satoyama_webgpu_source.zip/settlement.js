// All architecture and field details are procedural geometry; no image assets.
export const settlementFootprints = [
  {x:65,z:-56,r:11,type:'house'}, {x:84,z:-66,r:9,type:'house'},
  {x:92,z:-48,r:8,type:'house'},
  {x:88,z:-27,rx:18,rz:18,type:'paddy'}, {x:-76,z:65,rx:24,rz:20,type:'paddy'}
];
export function addSettlement(T,scene,getH,{low=false}={}) {
 const root=new T.Group();root.name='Satoyama village and terraced rice';scene.add(root);
 let seed=34981;const rand=()=>((seed=(seed*1664525+1013904223)>>>0)/4294967296);
 const mat=(color,extra={})=>new T.MeshStandardMaterial({color,roughness:1,...extra});
 const wood=mat('#574330'),lightWood=mat('#8a6845'),plaster=mat('#ccbd94'),paper=mat('#e5d9ac'),dark=mat('#302d23');
 const straw=[mat('#ae9160'),mat('#bca06a'),mat('#c8ad75'),mat('#9b8053')],stone=mat('#858672'),earth=mat('#746c3e'),bankGrass=mat('#8e9a4e');
 const boxGeo=new T.BoxGeometry(1,1,1);
 function box(parent,x,y,z,w,h,d,m){const o=new T.Mesh(boxGeo,m);o.position.set(x,y,z);o.scale.set(w,h,d);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;}
 function beam(parent,a,b,r,m){const v=new T.Vector3().subVectors(b,a);const o=new T.Mesh(new T.CylinderGeometry(r,r,v.length(),5),m);o.position.copy(a).add(b).multiplyScalar(.5);o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v.normalize());o.castShadow=true;parent.add(o);return o;}
 const v=(x,y,z)=>new T.Vector3(x,y,z);
 function house(cx,cz,w,d,angle){
  const g=new T.Group();root.add(g);g.position.set(cx,0,cz);g.rotation.y=angle;
  const world=(x,z)=>[cx+x*Math.cos(angle)+z*Math.sin(angle),cz-x*Math.sin(angle)+z*Math.cos(angle)];
  let base=-Infinity;for(const x of [-w/2,w/2])for(const z of [-d/2,d/2]){const p=world(x,z);base=Math.max(base,getH(...p));}base+=.25;
  // Foundation settles into the actual slope, not a hovering flat box.
  for(let x=-w/2;x<w/2;x+=1.15)for(const z of [-d/2,d/2]){const p=world(x,z),h=Math.max(.5,base-getH(...p)+.25);box(g,x,base-h/2,z,1.1,h,.85,stone);}
  for(let z=-d/2;z<d/2;z+=1.1)for(const x of [-w/2,w/2]){const p=world(x,z),h=Math.max(.5,base-getH(...p)+.25);box(g,x,base-h/2,z,.85,h,1.05,stone);}
  box(g,0,base+.16,0,w,.35,d,wood);
  const wallH=w*.25,eave=base+wallH,rise=w*.43;
  box(g,0,base+wallH/2,0,w*.92,wallH,d*.91,plaster);
  for(let x=-w*.46;x<=w*.47;x+=w/6)for(const z of [-d*.465,d*.465])box(g,x,base+wallH/2,z,.22,wallH,.22,wood);
  for(const y of [base+.45,eave-.15]){box(g,0,y,d*.47,w,.2,.25,wood);box(g,0,y,-d*.47,w,.2,.25,wood);}
  // Front shoji panels with wooden mullions and an open dark entrance.
  for(const x of [-w*.29,w*.27]){
   box(g,x,base+wallH*.53,d*.475,w*.26,wallH*.65,.08,paper);
   for(let j=-2;j<=2;j++)box(g,x+j*w*.052,base+wallH*.53,d*.487,.055,wallH*.65,.07,lightWood);
   for(let j=0;j<4;j++)box(g,x,base+wallH*.22+j*wallH*.2,d*.49,w*.26,.055,.07,lightWood);
  }
  box(g,0,base+wallH*.43,d*.48,w*.14,wallH*.82,.1,dark);
  for(let j=0;j<4;j++)box(g,-w*.06+j*w*.04,base+wallH*.43,d*.49,.055,wallH*.82,.06,wood);
  box(g,0,base+.32,d*.59,w*1.02,.18,d*.22,lightWood);
  // Hipped gassho-like thatch roof: real sloped faces, layered straw eaves.
  const rw=w*.6,rd=d*.64,ridge=w*.29;
  const vertices=[-rw,eave,-rd, rw,eave,-rd, rw,eave,rd, -rw,eave,rd, -ridge,eave+rise,0,ridge,eave+rise,0];
  const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(vertices,3));geo.setIndex([0,4,5,0,5,1,3,2,5,3,5,4,0,3,4,1,5,2]);geo.computeVertexNormals();
  const roof=new T.Mesh(geo,straw[0]);roof.material.side=T.DoubleSide;roof.castShadow=true;roof.receiveShadow=true;g.add(roof);
  for(const side of [-1,1]){
   const bands=low?9:16;
   for(let j=0;j<bands;j++){const t=j/bands,z=side*rd*(1-t),y=eave+rise*t;const width=2*(rw*(1-t)+ridge*t);
    const strip=box(g,0,y+.035,z,width,.13,rd/bands*1.25,straw[j%4]);strip.rotation.x=side*Math.atan2(rise,rd);
   }
   for(let j=0;j<(low?20:44);j++){
    const u=(j+.5)/(low?20:44)*2-1;
    beam(g,v(u*rw,eave+.08,side*rd),v(u*ridge,eave+rise+.08,0),.027,straw[j%4]);
   }
  }
  beam(g,v(-ridge-.45,eave+rise+.15,0),v(ridge+.45,eave+rise+.15,0),.23,wood);
  for(let x=-ridge;x<=ridge;x+=.8){beam(g,v(x,eave+rise-.15,-.48),v(x,eave+rise+.38,.2),.055,wood);beam(g,v(x,eave+rise-.15,.48),v(x,eave+rise+.38,-.2),.055,wood);}
  // Firewood beneath the side eave.
  for(let j=0;j<8;j++)box(g,-w*.51,base+.3+(j%2)*.3,-d*.2+Math.floor(j/2)*.55,.7,.23,.45,lightWood);
 }
 house(65,-56,15,10,.12);house(84,-66,11,8,-.18);house(92,-48,9,7,.15);
 const grainMat=mat('#d3b44f'),leafMat=mat('#859848'),wetMat=mat('#759c91',{roughness:.28,metalness:.1,transparent:true,opacity:.88});
 const stalkGeo=new T.ConeGeometry(.14,1.15,3),grainGeo=new T.ConeGeometry(.15,.54,4);
 function paddy(cx,cz,width,depth,rows){
  for(let r=0;r<rows;r++){
   const z0=cz-depth/2+r*depth/rows,z1=z0+depth/rows-.65,half=width/2*(.82+.18*Math.sin((r+.5)/rows*Math.PI));
   const points=[];const segments=24;
   // Gentle contour-following crescent; each terrace is a level flooded bed.
   for(let j=0;j<=segments;j++){const x=-half+j/segments*half*2,curve=2.2*(x/half)**2;points.push([cx+x,z0+curve]);}
   for(let j=segments;j>=0;j--){const x=-half+j/segments*half*2,curve=2.2*(x/half)**2;points.push([cx+x,z1+curve]);}
   let level=-Infinity;for(const [x,z] of points)level=Math.max(level,getH(x,z));level+=.1;
   const shape=new T.Shape();points.forEach(([x,z],i)=>i?shape.lineTo(x,-z):shape.moveTo(x,-z));shape.closePath();
   const mesh=new T.Mesh(new T.ShapeGeometry(shape),r%3===2?wetMat:earth);mesh.rotation.x=-Math.PI/2;mesh.position.y=level;mesh.receiveShadow=true;root.add(mesh);
   // Retaining bank descends to local ground all along its perimeter.
   for(let j=0;j<points.length;j++){
    const a=points[j],b=points[(j+1)%points.length],dx=b[0]-a[0],dz=b[1]-a[1],len=Math.hypot(dx,dz),mx=(a[0]+b[0])/2,mz=(a[1]+b[1])/2,h=Math.max(.55,level-getH(mx,mz)+.3);
    const bank=box(root,mx,level-h/2,mz,len+.08,h,.6,stone);bank.rotation.y=-Math.atan2(dz,dx);
    const rim=box(root,mx,level+.12,mz,len+.12,.25,.8,bankGrass);rim.rotation.y=bank.rotation.y;
    if(!low)for(let k=0;k<3;k++){const q=box(root,mx+(rand()-.5)*len,level-.2-rand()*Math.min(h,.65),mz+(rand()-.5)*.65,.35+rand()*.3,.28,.3,stone);q.rotation.y=rand();}
   }
   const step=low?1.25:.78,positions=[];
   for(let x=-half+.9;x<half-.8;x+=step)for(let z=z0+.7;z<z1-.4;z+=step){positions.push([cx+x,z+2.2*(x/half)**2]);}
   const plants=new T.InstancedMesh(stalkGeo,r%3===2?leafMat:grainMat,positions.length),heads=new T.InstancedMesh(grainGeo,grainMat,positions.length),dummy=new T.Object3D();
   positions.forEach(([x,z],i)=>{const tall=r%3===2?.48:.9+rand()*.3;dummy.position.set(x,level+tall*.5,z);dummy.rotation.set(0,rand()*6.28,(rand()-.5)*.15);dummy.scale.set(.9,tall,.9);dummy.updateMatrix();plants.setMatrixAt(i,dummy.matrix);dummy.position.y=level+tall;dummy.rotation.z=.35;dummy.scale.set(.8,.7,.8);dummy.updateMatrix();heads.setMatrixAt(i,dummy.matrix);});
   plants.castShadow=true;plants.receiveShadow=true;root.add(plants);if(r%3!==2)root.add(heads);
  }
 }
 paddy(88,-27,31,28,4);paddy(-76,65,43,33,4);
 batchStaticMeshes(T,root);
 return {group:root,footprints:settlementFootprints};
}

// Bake root-local transforms once, then combine compatible static geometry.
// Instanced rice remains instanced. No shaders or renderer-specific hooks.
function batchStaticMeshes(T,root) {
 root.updateWorldMatrix(true,true);
 const inverseRoot=new T.Matrix4().copy(root.matrixWorld).invert();
 const buckets=new Map();let before=0,verticesBefore=0;
 root.traverse(o=>{
  if(!o.isMesh)return;
  before++;
  if(o.isInstancedMesh||Array.isArray(o.material)||o.geometry.morphAttributes.position)return;
  const source=o.geometry;
  const g=source.index?source.toNonIndexed():source.clone();
  g.applyMatrix4(new T.Matrix4().multiplyMatrices(inverseRoot,o.matrixWorld));
  const names=Object.keys(g.attributes).sort();
  const signature=names.map(n=>{const a=g.attributes[n];return `${n}:${a.itemSize}:${a.normalized}:${a.array.constructor.name}`}).join('|');
  const key=`${o.material.uuid}:${o.castShadow}:${o.receiveShadow}:${o.renderOrder}:${signature}`;
  if(!buckets.has(key))buckets.set(key,{material:o.material,castShadow:o.castShadow,receiveShadow:o.receiveShadow,renderOrder:o.renderOrder,names,items:[]});
  buckets.get(key).items.push({mesh:o,geometry:g});verticesBefore+=g.attributes.position.count;
 });
 let mergedVertices=0;
 for(const bucket of buckets.values()){
  const merged=new T.BufferGeometry();
  for(const name of bucket.names){
   const first=bucket.items[0].geometry.attributes[name];
   const length=bucket.items.reduce((sum,it)=>sum+it.geometry.attributes[name].array.length,0);
   const array=new first.array.constructor(length);let offset=0;
   for(const it of bucket.items){const a=it.geometry.attributes[name].array;array.set(a,offset);offset+=a.length;}
   merged.setAttribute(name,new T.BufferAttribute(array,first.itemSize,first.normalized));
  }
  merged.computeBoundingBox();merged.computeBoundingSphere();
  const mesh=new T.Mesh(merged,bucket.material);mesh.name='Static village batch';mesh.castShadow=bucket.castShadow;mesh.receiveShadow=bucket.receiveShadow;mesh.renderOrder=bucket.renderOrder;
  root.add(mesh);mergedVertices+=merged.attributes.position.count;
  for(const it of bucket.items){it.mesh.removeFromParent();it.geometry.dispose();}
 }
 let after=0,instances=0;root.traverse(o=>{if(o.isMesh){after++;if(o.isInstancedMesh)instances+=o.count;}});
 root.userData.batching={drawCallsBefore:before,drawCallsAfter:after,staticBatches:buckets.size,verticesBefore,verticesAfter:mergedVertices,riceInstances:instances};
}
