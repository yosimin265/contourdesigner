import {getH,pondR,nearLine,routes,streamPoints,addTerrain,addContours} from './terrain.js';
import {addVegetation} from './vegetation.js';
import {addSettlement} from './settlement.js';
import {addWater} from './water.js';
export const referenceEye=[2,102,125],referenceTarget=[-5,-9,-12];
function excludes(x,z){
 if(pondR(x,z)<1.08||z>35&&nearLine(x,z,streamPoints)[0]<3.6)return true;
 if(routes.some(l=>nearLine(x,z,l)[0]<2.1))return true;
 if(Math.abs(x+76)<24&&Math.abs(z-65)<22||Math.abs(x-88)<20&&Math.abs(z+27)<18)return true;
 return [[65,-56],[84,-66],[92,-48]].some(a=>Math.hypot(x-a[0],z-a[1])<10);
}
function extras(T,scene,low){
 const g=new T.IcosahedronGeometry(1,1),mat=new T.MeshStandardMaterial({color:'#a4a59a',roughness:1});
 const rock=new T.InstancedMesh(g,mat,low?160:315);
 const o=new T.Object3D(),c=new T.Color();
 let state=38401;const rng=()=>((state=Math.imul(state,1664525)+1013904223>>>0)/4294967296);
 for(let i=0;i<rock.count;i++){
  let x,z,j=0;do{x=(rng()-.5)*250;z=(rng()-.5)*205-7;j++}while(j<20&&excludes(x,z));
  const r=rng()**4*1.65+.12,y=getH(x,z);
  o.position.set(x,y-r*.15,z);o.rotation.set(rng()*.5,rng()*7,rng()*.25);o.scale.set(r*(1+rng()),r*(.4+rng()*.4),r*(.9+rng()*.55));o.updateMatrix();rock.setMatrixAt(i,o.matrix);
  c.setHSL(.105+rng()*.10,.07+rng()*.13,.34+rng()*.22);rock.setColorAt(i,c);
 }
 rock.receiveShadow=!low;rock.castShadow=!low;scene.add(rock);
 // Crest marker is a stone outcrop, not a game icon.
 for(let i=0;i<8;i++){const x=-47+(rng()-.5)*6,z=-26+(rng()-.5)*5,rr=.55+rng()*.89;
 const m=new T.Mesh(g,mat);m.scale.set(rr*1.4,rr*.65,rr);m.position.set(x,getH(x,z)+rr*.21,z);m.rotation.y=rng()*7;m.castShadow=!low;scene.add(m);}
}

export function populate(T,scene,low){
 const sun=new T.DirectionalLight('#fff0bd',2.3);sun.position.set(-92,112,48);sun.target.position.set(0,0,-13);
 sun.castShadow=!low;sun.shadow.mapSize.set(1536,1536);
 Object.assign(sun.shadow.camera,{left:-128,right:128,top:125,bottom:-125,near:12,far:280});sun.shadow.bias=-.00025;sun.shadow.normalBias=.25;
 scene.add(sun,sun.target,new T.HemisphereLight('#e2f0f4','#78865b',1.8));
 const bounce=new T.DirectionalLight('#cedee6',.45);bounce.position.set(73,35,-94);scene.add(bounce);
 addTerrain(T,scene,low);
 addSettlement(T,scene,getH,{low});
 addVegetation(T,scene,getH,{seed:64,low,exclusions:excludes});
 extras(T,scene,low);
 const animateWater=addWater(T,scene,getH,{low,streamPoints});
 return {animateWater,contours:addContours(T,scene)};
}
