/** Seeded painterly woodland. All geometry/materials are shared and instanced. */
export function addVegetation(T, scene, getH, { seed = 731, low = false, exclusions = () => false } = {}) {
  let state = (Number(seed) || 731) >>> 0;
  const random = () => { state += 0x6D2B79F5; let t = state; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  const range = (a,b) => a + (b-a)*random();
  const root = new T.Group(); root.name = 'Painterly satoyama vegetation'; scene.add(root);
  const bins = { wood: [], foliage: [], blossom: [], leaf: [], grass: [], flowers: [], distant: [] };
  const color = hex => new T.Color(hex);
  const greens = ['#667c42','#7b8b45','#a2a65a','#b6b55c','#576e47','#446851','#8c9c55'];
  const safe = (x,z,margin=0) => {
    if (Math.abs(x)>113 || Math.abs(z)>113 || exclusions(x,z)) return false;
    if (((x-39)/30)**2+((z-22)/21)**2<1) return false;
    if (z>26 && Math.abs(x-(39*(107-z)/81))<5) return false;
    if (margin && [[margin,0],[-margin,0],[0,margin],[0,-margin]].some(([a,b])=>exclusions(x+a,z+b))) return false;
    return Number.isFinite(getH(x,z));
  };
  const add = (bin,x,y,z,sx,sy,sz,c,rx=0,ry=0,rz=0) => bins[bin].push({x,y,z,sx,sy,sz,c,rx,ry,rz});
  const tree = (x,z,scale=1,pink=false) => {
    if (!safe(x,z,2.8*scale)) return;
    const y=getH(x,z), h=range(4.5,7.5)*scale, spread=range(2.6,4.0)*scale;
    const tint=color(pink ? '#e8b7b4' : greens[Math.floor(random()*greens.length)]);
    add('wood',x,y+h*.43,z,.24*scale,h*.86,.24*scale,'#6b6850',0,range(0,6.28),range(-.06,.06));
    // Divergent branch structure remains visible beneath loose crowns.
    const branches=pink?5:3;
    for(let b=0;b<branches;b++){
      const a=b/branches*Math.PI*2+random()*.5, length=h*.51;
      add('wood',x+Math.cos(a)*spread*.22,y+h*.67,z+Math.sin(a)*spread*.22,.115*scale,length,.115*scale,'#75715a',Math.sin(a)*.52,0,-Math.cos(a)*.52);
    }
    const lobes=low?5:(pink?7:6);
    for(let k=0;k<lobes;k++){
      const a=k/lobes*Math.PI*2+range(-.3,.3), rad=k===0?0:spread*.65;
      const cx=x+Math.cos(a)*rad, cz=z+Math.sin(a)*rad;
      const cy=y+h+(k===0?spread*.36:range(-.5,.35)*scale);
      const r=spread*range(.53,.75), light=.91+random()*.22+(k===0?.06:0);
      add(pink?'blossom':'foliage',cx,cy,cz,r,r*range(.62,.9),r,tint.clone().multiplyScalar(light),range(0,1),range(0,6.28),0);
      // Small irregular leaf clusters break up the otherwise spherical silhouette.
      const sprays=low?2:7;
      for(let q=0;q<sprays;q++){
        const aa=range(0,Math.PI*2), rr=r*range(.65,1.05);
        const lx=cx+Math.cos(aa)*rr, lz=cz+Math.sin(aa)*rr, ly=cy+range(-.25,.62)*r;
        const s=range(.35,.67)*scale;
        add(pink?'blossom':'leaf',lx,ly,lz,s,s*.42,s*.72,tint.clone().multiplyScalar(range(.96,1.24)),range(-.5,.5),aa,range(-.3,.3));
      }
    }
  };
  // Poisson-like seeded spacing; no rows, and intentionally no trees on the hero's face.
  const occupied=[];
  const attempts=low?1100:3400;
  for(let i=0;i<attempts;i++){
    if(low && occupied.length>=135) break;
    const x=range(-111,111),z=range(-109,108);
    const edge=Math.max(0,(Math.abs(x)-70)/35), back=Math.max(0,(-z-58)/42);
    let density=Math.min(.86,.025+edge*.75+back*.72);
    const hero=((x+44)/49)**2+((z+25)/52)**2;
    if(hero<1.12) density*=.025;
    if(x>30 && x<99 && z>-83 && z<-30) density*=.12;
    if(z>0 && Math.abs(x-8)<43) density*=.18;
    if(random()>density || !safe(x,z,3)) continue;
    if(occupied.some(p=>(p[0]-x)**2+(p[1]-z)**2<25)) continue;
    occupied.push([x,z]); tree(x,z,range(.72,1.22),random()<.075);
  }
  // Readable flowering accent trees around, not inside, the scenery's key spaces.
  [[-87,-34,.9],[-89,24,1],[-70,83,.85],[13,-54,.8],[45,-82,.85],[91,-65,.8],[88,41,.9]].forEach(([x,z,s])=>tree(x,z,s,true));
  [[-82,-71,1.2],[-96,68,1.1],[92,77,1.1],[84,-91,1.05]].forEach(([x,z,s])=>tree(x,z,s,false));
  // Frame the nearer paddy with denser, deliberately grouped woodland.
  for (const [cx,cz,r,n] of [[-67,28,15,10],[-53,56,9,8],[-38,70,8,7],[92,40,13,9],[78,68,12,8],[-83,-47,8,5]]) {
    for(let i=0;i<(low?Math.ceil(n*.55):n);i++){const a=range(0,6.283), d=Math.sqrt(random())*r;tree(cx+Math.cos(a)*d,cz+Math.sin(a)*d,range(.68,1.18),i===0&&random()>.42);}
  }
  // A second, low-poly forest layer continues the backdrop past the near tree line.
  for(let i=0;i<(low?220:660);i++){
    const x=range(-160,150),z=range(-174,-77);
    if(z>-106&&x>21&&x<105&&random()<.77)continue;
    if(z>-97&&x<-26&&x>-117)continue;
    const size=range(2.0,4.9),y=getH(x,z),t=color(greens[Math.floor(random()*greens.length)]).lerp(new T.Color('#658476'),range(.16,.39));
    add('distant',x,y+size*.95,z,size,size*range(.86,1.48),size*.87,t,0,range(0,6.28),0);
  }
  // Low shrubs give the middle ground detail without obscuring contour lines.
  for(let i=0;i<(low?180:360);i++){
    const x=range(-110,110),z=range(-100,108);
    if(!safe(x,z,1.2))continue;
    if(((x+44)/42)**2+((z+25)/44)**2<1 && random()<.88)continue;
    const s=range(.65,1.65),t=color(greens[Math.floor(random()*greens.length)]);
    add('foliage',x,getH(x,z)+s*.5,z,s,s*.63,s*.8,t,0,range(0,6.28),0);
  }
  for(let i=0;i<(low?2300:6500);i++){
    const x=range(-113,113),z=range(-109,112);if(!safe(x,z,.35))continue;
    const h=getH(x,z),s=range(.4,1.05), c=random()<.25?'#cac082':random()<.5?'#809750':'#a1aa6a';
    add('grass',x,h+.035,z,s,s*range(.55,1),s,c,0,range(0,6.28),0);
    if(random()<.045){ const v=range(.12,.24);add('flowers',x,h+s*.76,z,v,v*.6,v,random()<.7?'#ede4b3':'#d6c5aa'); }
  }
  // A rough, faceted crown catches broad light like a watercolor foliage mass.
  const crown=new T.IcosahedronGeometry(1,low?0:1), pos=crown.attributes.position;
  const vertexColors=[];
  for(let i=0;i<pos.count;i++){
    const x=pos.getX(i),y=pos.getY(i),z=pos.getZ(i);
    // Coordinate-based noise preserves shared vertices and avoids cracked triangles.
    const n=Math.sin(x*19.2+y*13.8+z*21.1)*Math.sin(x*7.1-z*11.3), f=1+n*.09;
    pos.setXYZ(i,x*f,y*f,z*f);
    const v=.88+Math.max(0,y)*.14+Math.max(0,-x)*.07+n*.065;vertexColors.push(v,v,v*.97);
  }
  crown.setAttribute('color',new T.Float32BufferAttribute(vertexColors,3)); crown.computeVertexNormals();
  const tuftPositions=[],tuftColors=[];
  for(let b=0;b<5;b++){
    const a=b/5*Math.PI*2,dx=Math.cos(a),dz=Math.sin(a),w=.09,height=.55+(b%3)*.18;
    tuftPositions.push(-dz*w,0,dx*w,dz*w,0,-dx*w,dx*.23,height,dz*.23);
    tuftColors.push(.72,.77,.64,.72,.77,.64,1.12,1.1,.9);
  }
  const tuft=new T.BufferGeometry();tuft.setAttribute('position',new T.Float32BufferAttribute(tuftPositions,3));tuft.setAttribute('color',new T.Float32BufferAttribute(tuftColors,3));tuft.computeVertexNormals();
  const wood=new T.CylinderGeometry(.65,1,1,5,1), petal=new T.IcosahedronGeometry(1,0);
  const materials={
    distant:new T.MeshStandardMaterial({roughness:1,color:0xffffff}),
    wood:new T.MeshStandardMaterial({roughness:1,metalness:0,color:0xffffff}),
    foliage:new T.MeshStandardMaterial({roughness:1,metalness:0,color:0xffffff,vertexColors:true}),
    blossom:new T.MeshStandardMaterial({roughness:1,metalness:0,color:0xffffff,vertexColors:true}),
    leaf:new T.MeshStandardMaterial({roughness:1,metalness:0,color:0xffffff,vertexColors:true}),
    grass:new T.MeshStandardMaterial({roughness:1,metalness:0,color:0xffffff,vertexColors:true,side:T.DoubleSide}),
    flowers:new T.MeshStandardMaterial({roughness:1,metalness:0,color:0xffffff})
  };
  const geometries={wood,foliage:crown,blossom:crown,leaf:crown,grass:tuft,flowers:petal,distant:petal};
  const dummy=new T.Object3D();const meshes=[];
  for(const [key,items] of Object.entries(bins)){
    if(!items.length)continue;
    const mesh=new T.InstancedMesh(geometries[key],materials[key],items.length);mesh.name=`Vegetation ${key}`;
    items.forEach((p,i)=>{dummy.position.set(p.x,p.y,p.z);dummy.rotation.set(p.rx,p.ry,p.rz);dummy.scale.set(p.sx,p.sy,p.sz);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);mesh.setColorAt(i,p.c?.isColor?p.c:color(p.c));});
    mesh.instanceMatrix.needsUpdate=true;if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true;
    mesh.castShadow=key==='wood'||key==='foliage'||key==='blossom';mesh.receiveShadow=true;
    if(mesh.computeBoundingSphere)mesh.computeBoundingSphere();root.add(mesh);meshes.push(mesh);
  }
  root.userData.treeCount=occupied.length;root.userData.instanceCounts=Object.fromEntries(Object.entries(bins).map(([k,v])=>[k,v.length]));
  return {group:root,meshes,dispose(){scene.remove(root);for(const g of new Set(Object.values(geometries)))g.dispose();for(const m of Object.values(materials))m.dispose();for(const m of meshes)m.dispose?.();}};
}
