import * as T from 'three/webgpu';
import {getH} from './terrain.js';
import {populate,referenceEye,referenceTarget} from './scenery.js';
const $=id=>document.getElementById(id), view=$('view'), params=new URLSearchParams(location.search);
if(params.has('photo'))view.classList.add('clean');
const handheld=matchMedia('(pointer:coarse)').matches||innerWidth<760;
const low=params.get('quality')==='low'||(params.get('quality')!=='high'&&handheld);
const scene=new T.Scene(), camera=new T.PerspectiveCamera(45,1,.34,560);
scene.background=new T.Color('#b8c8aa');
scene.fog=new T.FogExp2('#bac9ad',.00455);
const renderer=new T.WebGPURenderer({antialias:!low,alpha:false,powerPreference:low?'low-power':'high-performance'});
renderer.outputColorSpace=T.SRGBColorSpace;
renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.18;
renderer.shadowMap.enabled=!low;renderer.shadowMap.type=T.PCFShadowMap;
view.prepend(renderer.domElement);
let orbit=false,el=.62,az=.01,radius=175,currentDpr=1,ready=false,windowFrames=0,windowMs=0,last=0,cool=0;
const heroP=new T.Vector3(...referenceEye),heroLook=new T.Vector3(...referenceTarget);
const pivot=new T.Vector3(1,5,-12);
const at=(v,min,max)=>Math.max(min,Math.min(max,v));
function place(){if(!orbit){camera.position.copy(heroP);camera.lookAt(heroLook);return}
 const rr=Math.cos(el)*radius;
 camera.position.set(pivot.x+Math.sin(az)*rr,pivot.y+Math.sin(el)*radius,pivot.z+Math.cos(az)*rr);
 camera.position.y=Math.max(camera.position.y,getH(camera.position.x,camera.position.z)+3);
 camera.lookAt(pivot);}
function size(){camera.aspect=innerWidth/innerHeight;camera.fov=camera.aspect<1.25?Math.min(114,2*Math.atan(Math.tan(Math.PI/8)*1.55/camera.aspect)*180/Math.PI):45;camera.updateProjectionMatrix();
 const d=Math.min(currentDpr,Math.sqrt((low?720000:2250000)/(innerWidth*innerHeight)));
 renderer.setPixelRatio(d);renderer.setSize(innerWidth,innerHeight);}
function setMode(b){if(b&&!orbit){const p=camera.position.clone().sub(pivot);radius=p.length();az=Math.atan2(p.x,p.z);el=Math.asin(p.y/radius);}orbit=b;$('orbit').classList.toggle('on',b);$('hero').classList.toggle('on',!b);place();}
const labels=[];
function addLabel(txt,x,y,z){const el=document.createElement('span');el.textContent=txt;el.className='elevation';$('labels').append(el);labels.push({el,p:new T.Vector3(x,y,z)});}
function displayLabels(){camera.updateMatrixWorld();for(const {el,p} of labels){const q=p.clone().project(camera);el.hidden=q.z>1||Math.abs(q.x)>1||Math.abs(q.y)>1;el.style.left=(q.x*.5+.5)*100+'%';el.style.top=(.5-q.y*.5)*100+'%';}}
const pointers=new Map();
renderer.domElement.onpointerdown=e=>{renderer.domElement.setPointerCapture(e.pointerId);pointers.set(e.pointerId,[e.clientX,e.clientY]);};
renderer.domElement.onpointermove=e=>{if(!pointers.has(e.pointerId))return;const a=pointers.get(e.pointerId),x=e.clientX,y=e.clientY,dx=x-a[0],dy=y-a[1];if(Math.abs(dx)+Math.abs(dy)<1)return;if(!orbit)setMode(true);
 if(pointers.size===2){const b=[...pointers.entries()].find(([k])=>k!==e.pointerId)[1];const s=Math.hypot(a[0]-b[0],a[1]-b[1]),n=Math.hypot(x-b[0],y-b[1]);if(n>7)radius=at(radius*s/n,34,295);}
 else{az-=dx*.009;el=at(el+dy*.006,.06,1.51);}
 pointers.set(e.pointerId,[x,y]);place();};
for(const k of ['pointerup','pointercancel','lostpointercapture'])renderer.domElement.addEventListener(k,e=>pointers.delete(e.pointerId));
renderer.domElement.addEventListener('wheel',e=>{e.preventDefault();if(!orbit)setMode(true);radius=at(radius*Math.exp(e.deltaY*.001),34,295);place();},{passive:false});
$('hero').onclick=()=>setMode(false);$('orbit').onclick=()=>setMode(true);
addEventListener('keydown',e=>{if(e.key==='1')setMode(false);if(e.key==='2')setMode(true);if(e.key.toLowerCase()==='c')$('contour').click();if(e.key.startsWith('Arrow')&&ready){e.preventDefault();if(!orbit)setMode(true);if(e.key==='ArrowLeft')az-=.09;if(e.key==='ArrowRight')az+=.09;if(e.key==='ArrowUp')radius=at(radius-9,34,295);if(e.key==='ArrowDown')radius=at(radius+9,34,295);place();}});
let taking=false;
$('photo').onclick=()=>{if(!ready||taking)return;taking=true;$('photo').textContent='保存中…';};
window.addEventListener('resize',()=>{if(ready)size();});
async function main(){
 await renderer.init();
 const backend=renderer.backend.isWebGPUBackend?'WebGPU':'WebGL 2（互換描画）';
 $('engine').textContent=backend+' · '+(low?'スマホ軽量':'高画質');
 currentDpr=Math.min(devicePixelRatio||1,low?1.13:1.65);
 size();place();
 const {animateWater,contours}=populate(T,scene,low);
 addLabel('40 m',-47,getH(-47,-26)+1.3,-26);
 addLabel('0 m',28,.7,39);addLabel('−5 m',39,1.2,22);
 $('labels').hidden=true;
 $('contour').onclick=()=>{contours.visible=!contours.visible;$('labels').hidden=!contours.visible;$('contour').setAttribute('aria-pressed',contours.visible);};
 ready=true;
 renderer.setAnimationLoop(now=>{
  if(document.hidden){last=0;return;}
  if(last){
   const dt=now-last;
   if(dt<600){windowFrames++;windowMs+=dt;}
   if(windowMs>3500){
    if(low&&now>cool&&windowMs/windowFrames>42&&currentDpr>.69){currentDpr=Math.max(.68,currentDpr*.85);size();cool=now+6000;$('engine').textContent=backend+' · スマホ軽量 / 自動調整';}
    windowFrames=windowMs=0;
   }
  } last=now;
  try{
   if(!params.has('freeze'))animateWater?.(now*.001);else animateWater?.(1.3);
   renderer.render(scene,camera);
   if(contours.visible)displayLabels();
   if(taking){taking=false;renderer.domElement.toBlob(blob=>{if(blob){const link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download='satoyama.png';link.click();setTimeout(()=>URL.revokeObjectURL(link.href),5000);}$('photo').textContent='撮影';},'image/png');}
   if(!window.satoyamaReady){$('boot').hidden=true;window.satoyamaReady=true;window.satoyamaBackend=backend;}
   window.satoyamaStats={backend,low,triangles:renderer.info.render.triangles,draws:renderer.info.render.drawCalls,resolution:[renderer.domElement.width,renderer.domElement.height]};
  }catch(error){renderer.setAnimationLoop(null);failure(error);}
 });
}
function failure(e){console.error(e);$('boot').hidden=false;$('boot').textContent='3D描画を開始できませんでした。\nWebGPU対応ブラウザで開くか、HTTPS／localhostでの表示をご確認ください。';}
main().catch(failure);
